package Spritecloudpakage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigationtolink {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shivangi Gupta\\OneDrive\\Desktop\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.uitestingplayground.com");
		//Navigate to the Link Dynamic ID
		driver.findElement(By.linkText("Dynamic ID")).click();
		driver.quit();
			
		
		

	}

}
