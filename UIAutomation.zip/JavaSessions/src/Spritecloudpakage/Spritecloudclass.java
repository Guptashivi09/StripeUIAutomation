package Spritecloudpakage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Spritecloudclass {

	public static void main(String[] args){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shivangi Gupta\\OneDrive\\Desktop\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.uitestingplayground.com");
		System.out.println(driver.getTitle());	
		
				

	}
	
}
